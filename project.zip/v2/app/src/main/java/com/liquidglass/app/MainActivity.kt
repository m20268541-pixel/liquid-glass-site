package com.liquidglass.app

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

private const val GLASS_SHADER = """
uniform shader background;
uniform float2 center;
uniform float2 halfSize;
uniform float corner;
uniform float bevel;
uniform float amount;

float sdf(float2 p) {
    float2 q = abs(p) - halfSize + corner;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - corner;
}

half4 main(float2 frag) {
    float2 p = frag - center;
    float d = sdf(p);
    if (d > 1.5) {
        return background.eval(frag);
    }
    float depth = max(-d, 0.0);
    float edge = 1.0 - clamp(depth / bevel, 0.0, 1.0);

    float2 grad = float2(
        sdf(p + float2(1.0, 0.0)) - sdf(p - float2(1.0, 0.0)),
        sdf(p + float2(0.0, 1.0)) - sdf(p - float2(0.0, 1.0))
    );
    float2 n = grad / max(length(grad), 0.0001);

    float2 offset = n * edge * edge * amount;
    half4 c = background.eval(frag + offset);
    c.r = background.eval(frag + offset * 1.08).r;
    c.b = background.eval(frag + offset * 0.92).b;

    float light = max(dot(n, normalize(float2(-1.0, -1.0))), 0.0);
    float rim = edge * edge * edge;
    c.rgb += half3(0.07 + rim * (0.18 + 0.55 * light));

    half aa = half(1.0 - smoothstep(-1.5, 1.5, d));
    return mix(background.eval(frag), c, aa);
}
"""

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { GlassScreen() }
    }
}

@Composable
fun GlassScreen() {
    var center by remember { mutableStateOf(Offset.Zero) }
    val shader = remember { RuntimeShader(GLASS_SHADER) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged {
                if (center == Offset.Zero) {
                    center = Offset(it.width / 2f, it.height * 0.6f)
                }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    center = center + dragAmount
                }
            }
            .graphicsLayer {
                shader.setFloatUniform("center", center.x, center.y)
                shader.setFloatUniform("halfSize", 150.dp.toPx(), 90.dp.toPx())
                shader.setFloatUniform("corner", 44.dp.toPx())
                shader.setFloatUniform("bevel", 30.dp.toPx())
                shader.setFloatUniform("amount", 34.dp.toPx())
                renderEffect = RenderEffect
                    .createRuntimeShaderEffect(shader, "background")
                    .asComposeRenderEffect()
            }
    ) {
        Image(
            painter = painterResource(R.drawable.bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}
